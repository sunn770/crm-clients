import { useState, useEffect } from "react";

const USERS = [
  { id: "admin", password: "admin123", name: "Administrateur" },
  { id: "david", password: "david2024", name: "David Sonigo" },
];

const MATERIEL_OPTIONS = [
  "Panneaux solaires",
  "Ballon thermodynamique",
  "Pompe à chaleur",
  "Climatisation",
  "Isolation",
  "Poêle à granulés",
  "Autre",
];

const initialForm = {
  nom: "",
  prenom: "",
  codePostal: "",
  ville: "",
  materiel: "",
  prixVendu: "",
  surcout: "",
  vendeur: "",
  commissionVendeur: "",
  telepro: "",
  commissionTelepro: "",
  numeroFacture: "",
  dateAppelFacturation: "",
  installateur: "",
  desinstalle: "",
  litige: "",
};

function LoginPage({ onLogin, error }) {
  const [id, setId] = useState("");
  const [pwd, setPwd] = useState("");
  const handleSubmit = () => onLogin(id, pwd);
  return (
    <div style={styles.loginWrap}>
      <div style={styles.loginCard}>
        <div style={styles.loginLogo}>
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <rect width="44" height="44" rx="12" fill="#1a1a2e"/>
            <path d="M10 22 L22 10 L34 22 L22 34 Z" fill="none" stroke="#e8b04b" strokeWidth="2.5"/>
            <circle cx="22" cy="22" r="4" fill="#e8b04b"/>
          </svg>
        </div>
        <h1 style={styles.loginTitle}>CRM Clients</h1>
        <p style={styles.loginSub}>Connectez-vous pour accéder à votre espace</p>
        <div style={styles.field}>
          <label style={styles.label}>Identifiant</label>
          <input style={styles.input} type="text" value={id} onChange={e => setId(e.target.value)} placeholder="Votre identifiant" onKeyDown={e => e.key === "Enter" && handleSubmit()} />
        </div>
        <div style={styles.field}>
          <label style={styles.label}>Mot de passe</label>
          <input style={styles.input} type="password" value={pwd} onChange={e => setPwd(e.target.value)} placeholder="••••••••" onKeyDown={e => e.key === "Enter" && handleSubmit()} />
        </div>
        {error && <div style={styles.error}>{error}</div>}
        <button style={styles.btnPrimary} onClick={handleSubmit}>Se connecter →</button>
      </div>
    </div>
  );
}

function Badge({ label, color }) {
  return (
    <span style={{ ...styles.badge, background: color + "22", color, border: `1px solid ${color}55` }}>
      {label}
    </span>
  );
}

function ClientCard({ client, onEdit, onDelete }) {
  return (
    <div style={styles.clientCard}>
      <div style={styles.cardHeader}>
        <div>
          <div style={styles.cardName}>{client.prenom} {client.nom}</div>
          <div style={styles.cardSub}>{client.codePostal} {client.ville}</div>
        </div>
        <div style={styles.cardActions}>
          <button style={styles.btnIcon} onClick={() => onEdit(client)}>✏️</button>
          <button style={{ ...styles.btnIcon, color: "#e05c5c" }} onClick={() => onDelete(client.id)}>🗑</button>
        </div>
      </div>
      <div style={styles.cardGrid}>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Matériel</span><Badge label={client.materiel || "—"} color="#5b8dee"/></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Prix vendu</span><span style={styles.cardItemVal}>{client.prixVendu ? Number(client.prixVendu).toLocaleString("fr-FR") + " €" : "—"}</span></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Surcoût</span><span style={styles.cardItemVal}>{client.surcout ? Number(client.surcout).toLocaleString("fr-FR") + " €" : "—"}</span></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Vendeur</span><span style={styles.cardItemVal}>{client.vendeur || "—"}</span></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Comm. vendeur</span><span style={{ ...styles.cardItemVal, color: "#4ade80" }}>{client.commissionVendeur ? Number(client.commissionVendeur).toLocaleString("fr-FR") + " €" : "—"}</span></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Téléprospecteur</span><span style={styles.cardItemVal}>{client.telepro || "—"}</span></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Comm. téléprospecteur</span><span style={{ ...styles.cardItemVal, color: "#4ade80" }}>{client.commissionTelepro ? Number(client.commissionTelepro).toLocaleString("fr-FR") + " €" : "—"}</span></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>N° facture</span><Badge label={client.numeroFacture || "—"} color="#e8b04b"/></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Date appel facturation</span><span style={styles.cardItemVal}>{client.dateAppelFacturation || "—"}</span></div>
        <div style={styles.cardItem}><span style={styles.cardItemLabel}>Installateur</span><span style={styles.cardItemVal}>{client.installateur || "—"}</span></div>
        <div style={styles.cardItem}>
          <span style={styles.cardItemLabel}>Désinstallé</span>
          {client.desinstalle === "Oui" ? <Badge label="Oui" color="#e05c5c"/> : client.desinstalle === "Non" ? <Badge label="Non" color="#4ade80"/> : <span style={styles.cardItemVal}>—</span>}
        </div>
        <div style={styles.cardItem}>
          <span style={styles.cardItemLabel}>Litige</span>
          {client.litige === "En cours" ? <Badge label="En cours" color="#e8b04b"/> : client.litige === "Résolue" ? <Badge label="Résolue" color="#4ade80"/> : <span style={styles.cardItemVal}>—</span>}
        </div>
      </div>
    </div>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div style={styles.modalOverlay} onClick={onClose}>
      <div style={styles.modal} onClick={e => e.stopPropagation()}>
        <div style={styles.modalHeader}>
          <h2 style={styles.modalTitle}>{title}</h2>
          <button style={styles.modalClose} onClick={onClose}>✕</button>
        </div>
        <div style={styles.modalBody}>{children}</div>
      </div>
    </div>
  );
}

const FormRow = ({ children }) => <div style={styles.formRow}>{children}</div>;
const FormCol = ({ children }) => <div style={styles.formCol}>{children}</div>;

function FormField({ label, name, type, placeholder, options, value, onChange }) {
  return (
    <div style={styles.field}>
      <label style={styles.label}>{label}</label>
      {options ? (
        <select style={styles.input} value={value} onChange={e => onChange(name, e.target.value)}>
          <option value="">— Sélectionner —</option>
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input style={styles.input} type={type || "text"} value={value} onChange={e => onChange(name, e.target.value)} placeholder={placeholder || ""} />
      )}
    </div>
  );
}

function ClientForm({ form, setForm, onSave, onCancel, editing }) {
  const handleChange = (key, val) => setForm(f => ({ ...f, [key]: val }));
  const Field = ({ label, name, type, placeholder, options }) => (
    <FormField label={label} name={name} type={type} placeholder={placeholder} options={options} value={form[name] || ""} onChange={handleChange} />
  );
  return (
    <div>
      <div style={styles.formSection}>
        <div style={styles.sectionTitle}>👤 Informations client</div>
        <FormRow><FormCol><Field label="Nom *" name="nom" placeholder="Dupont"/></FormCol><FormCol><Field label="Prénom *" name="prenom" placeholder="Jean"/></FormCol></FormRow>
        <FormRow><FormCol><Field label="Code postal" name="codePostal" placeholder="75001"/></FormCol><FormCol><Field label="Ville" name="ville" placeholder="Paris"/></FormCol></FormRow>
      </div>
      <div style={styles.formSection}>
        <div style={styles.sectionTitle}>🔧 Installation</div>
        <FormRow><FormCol><Field label="Matériel installé" name="materiel" options={MATERIEL_OPTIONS}/></FormCol><FormCol><Field label="N° de facture" name="numeroFacture" placeholder="F-2026-0001"/></FormCol></FormRow>
        <FormRow><FormCol><Field label="Prix vendu (€)" name="prixVendu" type="number" placeholder="0"/></FormCol><FormCol><Field label="Surcoût (€)" name="surcout" type="number" placeholder="0"/></FormCol></FormRow>
      </div>
      <div style={styles.formSection}>
        <div style={styles.sectionTitle}>💼 Équipe commerciale</div>
        <FormRow><FormCol><Field label="Vendeur" name="vendeur" placeholder="Nom du vendeur"/></FormCol><FormCol><Field label="Commission vendeur (€)" name="commissionVendeur" type="number" placeholder="0"/></FormCol></FormRow>
        <FormRow><FormCol><Field label="Téléprospecteur" name="telepro" placeholder="Nom du téléprospecteur"/></FormCol><FormCol><Field label="Commission téléprospecteur (€)" name="commissionTelepro" type="number" placeholder="0"/></FormCol></FormRow>
      </div>
      <div style={styles.formSection}>
        <div style={styles.sectionTitle}>📋 Suivi dossier</div>
        <FormRow><FormCol><Field label="Date appel à facturation" name="dateAppelFacturation" type="date"/></FormCol><FormCol><Field label="Installateur" name="installateur" placeholder="Nom de l'installateur"/></FormCol></FormRow>
        <FormRow><FormCol><Field label="Désinstallé" name="desinstalle" options={["Oui", "Non"]}/></FormCol><FormCol><Field label="Litige" name="litige" options={["En cours", "Résolue"]}/></FormCol></FormRow>
      </div>
      <div style={styles.formActions}>
        <button style={styles.btnSecondary} onClick={onCancel}>Annuler</button>
        <button style={styles.btnPrimary} onClick={onSave}>{editing ? "✓ Mettre à jour" : "+ Créer le client"}</button>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [loginError, setLoginError] = useState("");
  const [clients, setClients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(initialForm);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    try {
      const saved = localStorage.getItem("crm-clients");
      if (saved) setClients(JSON.parse(saved));
    } catch (e) {}
    setLoading(false);
  }, []);

  useEffect(() => {
    if (loading) return;
    localStorage.setItem("crm-clients", JSON.stringify(clients));
  }, [clients, loading]);

  const getNextId = () => clients.length === 0 ? 1 : Math.max(...clients.map(c => c.id || 0)) + 1;

  const handleLogin = (id, pwd) => {
    const found = USERS.find(u => u.id === id && u.password === pwd);
    if (found) { setUser(found); setLoginError(""); }
    else setLoginError("Identifiant ou mot de passe incorrect.");
  };

  const openCreate = () => { setForm(initialForm); setEditingId(null); setShowModal(true); };
  const openEdit = (client) => { setForm({ ...client }); setEditingId(client.id); setShowModal(true); };

  const handleSave = () => {
    if (!form.nom.trim() || !form.prenom.trim()) { alert("Le nom et le prénom sont obligatoires."); return; }
    if (editingId) setClients(cs => cs.map(c => c.id === editingId ? { ...form, id: editingId } : c));
    else setClients(cs => [...cs, { ...form, id: getNextId() }]);
    setShowModal(false);
  };

  const handleDelete = (id) => { if (window.confirm("Supprimer ce client ?")) setClients(cs => cs.filter(c => c.id !== id)); };

  const filtered = clients.filter(c => {
    const q = search.toLowerCase();
    return [c.nom, c.prenom, c.ville, c.vendeur, c.telepro, c.numeroFacture, c.materiel].some(v => (v || "").toLowerCase().includes(q));
  });

  if (loading) return <div style={{ minHeight: "100vh", background: "#0f0f1a", display: "flex", alignItems: "center", justifyContent: "center", color: "#e8b04b", fontFamily: "Georgia, serif" }}>Chargement…</div>;
  if (!user) return <LoginPage onLogin={handleLogin} error={loginError}/>;

  return (
    <div style={styles.app}>
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <svg width="32" height="32" viewBox="0 0 44 44" fill="none">
            <rect width="44" height="44" rx="10" fill="#1a1a2e"/>
            <path d="M10 22 L22 10 L34 22 L22 34 Z" fill="none" stroke="#e8b04b" strokeWidth="2.5"/>
            <circle cx="22" cy="22" r="4" fill="#e8b04b"/>
          </svg>
          <span style={styles.headerTitle}>CRM Clients</span>
        </div>
        <div style={styles.headerRight}>
          <span style={styles.headerUser}>👤 {user.name}</span>
          <button style={styles.btnLogout} onClick={() => setUser(null)}>Déconnexion</button>
        </div>
      </header>
      <div style={styles.toolbar}>
        <div style={styles.statsRow}>
          <div style={styles.stat}><span style={styles.statNum}>{clients.length}</span><span style={styles.statLabel}>clients</span></div>
          <div style={styles.stat}><span style={styles.statNum}>{clients.reduce((s, c) => s + (Number(c.prixVendu) || 0), 0).toLocaleString("fr-FR")} €</span><span style={styles.statLabel}>CA total</span></div>
          <div style={styles.stat}><span style={styles.statNum}>{clients.reduce((s, c) => s + (Number(c.commissionVendeur) || 0) + (Number(c.commissionTelepro) || 0), 0).toLocaleString("fr-FR")} €</span><span style={styles.statLabel}>commissions</span></div>
        </div>
        <div style={styles.toolbarRight}>
          <input style={styles.searchInput} placeholder="🔍  Rechercher..." value={search} onChange={e => setSearch(e.target.value)} />
          <button style={styles.btnPrimary} onClick={openCreate}>+ Nouveau client</button>
        </div>
      </div>
      <div style={styles.grid}>
        {filtered.length === 0 ? (
          <div style={styles.empty}>{clients.length === 0 ? "Aucun client pour le moment. Créez votre premier client !" : "Aucun résultat."}</div>
        ) : filtered.map(c => <ClientCard key={c.id} client={c} onEdit={openEdit} onDelete={handleDelete}/>)}
      </div>
      {showModal && (
        <Modal title={editingId ? "Modifier le client" : "Nouveau client"} onClose={() => setShowModal(false)}>
          <ClientForm form={form} setForm={setForm} onSave={handleSave} onCancel={() => setShowModal(false)} editing={!!editingId}/>
        </Modal>
      )}
    </div>
  );
}

const styles = {
  app: { minHeight: "100vh", background: "#0f0f1a", color: "#e8e8f0", fontFamily: "'Georgia', 'Times New Roman', serif" },
  header: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 28px", background: "#14142b", borderBottom: "1px solid #2a2a4a", position: "sticky", top: 0, zIndex: 50 },
  headerLeft: { display: "flex", alignItems: "center", gap: 10 },
  headerTitle: { fontSize: 20, fontWeight: "bold", color: "#e8b04b", letterSpacing: 1 },
  headerRight: { display: "flex", alignItems: "center", gap: 14 },
  headerUser: { fontSize: 13, color: "#9898b8" },
  btnLogout: { background: "transparent", border: "1px solid #3a3a5a", color: "#9898b8", padding: "6px 14px", borderRadius: 6, cursor: "pointer", fontSize: 12 },
  toolbar: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 28px", gap: 16, flexWrap: "wrap", borderBottom: "1px solid #1e1e38" },
  statsRow: { display: "flex", gap: 28, alignItems: "center" },
  stat: { display: "flex", flexDirection: "column" },
  statNum: { fontSize: 22, fontWeight: "bold", color: "#e8b04b" },
  statLabel: { fontSize: 11, color: "#6868a0", textTransform: "uppercase", letterSpacing: 1 },
  toolbarRight: { display: "flex", gap: 10, alignItems: "center" },
  searchInput: { background: "#14142b", border: "1px solid #2a2a4a", borderRadius: 8, padding: "9px 16px", color: "#e8e8f0", fontSize: 13, outline: "none", width: 220 },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: 20, padding: 28 },
  empty: { gridColumn: "1/-1", textAlign: "center", color: "#5858a0", padding: "80px 0", fontSize: 15 },
  clientCard: { background: "#14142b", borderRadius: 12, border: "1px solid #2a2a4a", padding: 20 },
  cardHeader: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 },
  cardName: { fontSize: 17, fontWeight: "bold", color: "#e8e8f0" },
  cardSub: { fontSize: 12, color: "#6868a0", marginTop: 2 },
  cardActions: { display: "flex", gap: 6 },
  btnIcon: { background: "transparent", border: "1px solid #2a2a4a", borderRadius: 6, cursor: "pointer", fontSize: 14, padding: "4px 8px" },
  cardGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px 16px" },
  cardItem: { display: "flex", flexDirection: "column", gap: 3 },
  cardItemLabel: { fontSize: 10, color: "#5858a0", textTransform: "uppercase", letterSpacing: 0.8 },
  cardItemVal: { fontSize: 13, color: "#c8c8e0" },
  badge: { display: "inline-block", fontSize: 11, padding: "2px 8px", borderRadius: 20, fontWeight: "bold", whiteSpace: "nowrap" },
  loginWrap: { minHeight: "100vh", background: "#0f0f1a", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Georgia', serif" },
  loginCard: { background: "#14142b", border: "1px solid #2a2a4a", borderRadius: 16, padding: "44px 40px", width: "100%", maxWidth: 380, display: "flex", flexDirection: "column", gap: 16 },
  loginLogo: { textAlign: "center" },
  loginTitle: { fontSize: 26, fontWeight: "bold", color: "#e8b04b", textAlign: "center", margin: 0 },
  loginSub: { fontSize: 13, color: "#6868a0", textAlign: "center", margin: 0 },
  field: { display: "flex", flexDirection: "column", gap: 6 },
  label: { fontSize: 12, color: "#8888b0", textTransform: "uppercase", letterSpacing: 0.8, fontWeight: "bold" },
  input: { background: "#0f0f1a", border: "1px solid #2a2a4a", borderRadius: 8, padding: "10px 14px", color: "#e8e8f0", fontSize: 14, outline: "none", fontFamily: "'Georgia', serif", width: "100%", boxSizing: "border-box" },
  error: { background: "#3a1a1a", border: "1px solid #7a3a3a", color: "#e05c5c", borderRadius: 8, padding: "10px 14px", fontSize: 13 },
  btnPrimary: { background: "#e8b04b", color: "#0f0f1a", border: "none", borderRadius: 8, padding: "11px 22px", fontSize: 14, fontWeight: "bold", cursor: "pointer", fontFamily: "'Georgia', serif", whiteSpace: "nowrap" },
  btnSecondary: { background: "transparent", color: "#8888b0", border: "1px solid #2a2a4a", borderRadius: 8, padding: "11px 22px", fontSize: 14, cursor: "pointer", fontFamily: "'Georgia', serif" },
  modalOverlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: 16 },
  modal: { background: "#14142b", border: "1px solid #2a2a4a", borderRadius: 14, width: "100%", maxWidth: 620, maxHeight: "90vh", overflowY: "auto", fontFamily: "'Georgia', serif" },
  modalHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 24px", borderBottom: "1px solid #2a2a4a", position: "sticky", top: 0, background: "#14142b", zIndex: 1 },
  modalTitle: { margin: 0, fontSize: 18, color: "#e8b04b" },
  modalClose: { background: "transparent", border: "none", color: "#6868a0", fontSize: 18, cursor: "pointer", lineHeight: 1 },
  modalBody: { padding: "20px 24px" },
  formSection: { marginBottom: 24, padding: "18px", background: "#0f0f1a", borderRadius: 10, border: "1px solid #1e1e38" },
  sectionTitle: { fontSize: 13, color: "#8888b0", fontWeight: "bold", marginBottom: 14, letterSpacing: 0.5 },
  formRow: { display: "flex", gap: 14, marginBottom: 12 },
  formCol: { flex: 1, minWidth: 0 },
  formActions: { display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 },
};
